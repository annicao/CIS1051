require("color")

function textout(str, x, y, clr, shadowOffset)
	shadowOffset = shadowOffset or 1
	clr = clr or colors.white
	love.graphics.setColor(colors.black)
	love.graphics.print(str, x + shadowOffset, y + shadowOffset)

	love.graphics.setColor(clr)
	love.graphics.print(str, x, y)
end

function textPrint(str, x, y, w, clr, shadowOffset, align)
	shadowOffset = shadowOffset or 1
	clr = clr or colors.white
	align = align or 'left'
	love.graphics.setColor(colors.black)
	love.graphics.printf(str, x + shadowOffset, y + shadowOffset, w, align)

	love.graphics.setColor(clr)
	love.graphics.printf(str, x, y, w, align)
end


function scaleToScreen(image)
	return love.graphics.getWidth() / image:getWidth(), love.graphics.getHeight() / image:getHeight()
end

images = {
    background = love.graphics.newImage('images/background.png'),
    player1 = love.graphics.newImage('images/p1.png'),
    player2 = love.graphics.newImage('images/p2.png'),

    board = love.graphics.newImage('images/board.png'),
    num = {
        love.graphics.newImage('images/1.png'),
         love.graphics.newImage('images/2.png'),
        love.graphics.newImage('images/3.png'),
         love.graphics.newImage('images/4.png'),
    }
}

fonts = {
    font16 = love.graphics.newFont('font.ttf', 16),
    font24 = love.graphics.newFont('font.ttf', 24),
    font36 = love.graphics.newFont('font.ttf', 36),
}