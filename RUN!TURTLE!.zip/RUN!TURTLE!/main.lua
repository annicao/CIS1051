require("color")
require("graphics")
require("animation")
require("tile")
require("game")

function draw_background(c)
	love.graphics.setColor(c, c, c, 1.0)
	width = love.graphics.getWidth()
	height = love.graphics.getHeight()
	backgroundQuad = love.graphics.newQuad(0, 0, width, height, width, height)	
	love.graphics.draw(images.background, backgroundQuad)
end

function draw_dice()
	love.graphics.setColor(colors.white)

	w = images.board:getWidth()
	h = images.board:getHeight()
	x = (love.graphics.getWidth() - w) / 2
	y = (love.graphics.getHeight() - h) / 2
    love.graphics.draw(images.board, x, y, 0, 1, 1, 0, 0)
    if dice.value ~= 0 then
    	w = images.num[dice.value]:getWidth()
		h = images.num[dice.value]:getHeight()
		x = (love.graphics.getWidth() - w) / 2
		y = (love.graphics.getHeight() - h) / 2
    	love.graphics.draw(images.num[dice.value], x, y, 0, 1, 1, 0, 0)
	end

	w = 300
	x = (love.graphics.getWidth() - w) / 2
	y = love.graphics.getHeight() / 2 + 60

	if game.round % 2 == 0 then
		love.graphics.setFont(fonts.font24)
		love.graphics.printf('player turn', x, y, w, "center")

		if game.state == gameState.start then
			love.graphics.setFont(fonts.font16)
			love.graphics.printf('press [space] to continue', x, y + 40, w, "center")
		end
	else
		love.graphics.setFont(fonts.font24)
		love.graphics.printf('AI turn', x, y, w, "center")
	end

end

function love.draw()
	width = love.graphics.getWidth()
	height = love.graphics.getHeight()
	w = 400
	love.window.setTitle('RUN!TURTLE!')

	if game.state == gameState.menu then
		draw_background(1.0)

		love.graphics.setFont(fonts.font36)
		love.graphics.setColor(colors.white)

		x = (width - w) / 2
		y = height / 2 - 150
		
		y = height / 2 - 250
		textPrint('RUN!TURTLE!', x, y, w, colors.black, 2, "center")
		love.graphics.setFont(fonts.font24)
		y = height / 2 + 150 + 60
		textPrint('press any key to continue', x, y + 25, w, colors.whiteSmoke, 1, "center")
		
	elseif game.state == gameState.loading then
		draw_background(1.0)

		love.graphics.setColor(1.0, 1.0, 1.0, 0.75)
		x = 50
		y = 50
		love.graphics.rectangle('fill', x, y, width - 100, height - 100)

		love.graphics.setFont(fonts.font36)
		love.graphics.setColor(colors.black)

		x = (width - w) / 2
		y = height / 2 - 150
		love.graphics.printf('Loading...', x, y, w, "center")

		love.graphics.setFont(fonts.font24)
		y = height / 2
		love.graphics.printf('The player and AI take turns to dice. Player can press [space] to dice. \n Have Fun!', x, y, w, "center")

		love.graphics.setFont(fonts.font16)
		y = height / 2 + 200
		love.graphics.printf('press any key to continue', x, y, w, "center")


	elseif game.state == gameState.win then
		draw_background(1.0)

		love.graphics.setColor(1.0, 1.0, 1.0, 0.75)
		x = 50
		y = 50
		love.graphics.rectangle('fill', x, y, width - 100, height - 100)

		love.graphics.setFont(fonts.font36)
		love.graphics.setColor(colors.black)

		x = (width - w) / 2
		y = height / 2 - 150
		love.graphics.printf('Game Over', x, y, w, "center")

		y = height / 2
		if game.winner == 1 then
			love.graphics.printf('You WIN! ^_^', x, y, w, "center")
		else
			love.graphics.printf('You LOSE.', x, y, w, "center")
		end

		love.graphics.setFont(fonts.font16)
		y = height / 2 + 200
		love.graphics.printf('press any key to continue', x, y, w, "center")

	else
		draw_background(0.25)
		draw_tiles()
		draw_dice()
	    
	    love.graphics.setColor(colors.white)
		
		player1:draw(1.0)
		player2:draw(1.0)
		
	end
    
end

function love.keypressed(key)
    if game.state == gameState.menu then
    	game.state = gameState.loading

    elseif game.state == gameState.loading then
    	initGame()
    	game.state = gameState.start

    elseif game.state == gameState.win then
    	game.state = gameState.menu

    else
	    if(love.keyboard.isDown("space")) then
	    	if game.round % 2 == 0 and game.state == gameState.start then
	    		game.state = gameState.dice
	    		dice.time = 0
	    	end
	    end
	end
    
end

function love.mousepressed(x,y,key)

end
