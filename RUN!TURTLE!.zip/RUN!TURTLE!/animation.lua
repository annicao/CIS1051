-- animation
direction = {
	left = 1,
	right = 2,
	up = 3,
	down = 0
}

directionName = {
	'down',
	'left',
	'right',
	'up',
}

animationState = {
	stand = 0,
	move = 1,

	play = 2,
}

animation = {
	id = 0,
	state = 0,
	x = 0,
	y = 0,
	speed = 0,

	image = nil,
	anim = false,
	direction = 0,
	frame = 0,
	frameDelay = 0,

	pos = 0,
	nextPos = 0,
	dx = 0,
	dy = 0,

	stop = 0,
}

function animation:new(id, image, ani, anim)
	obj = {}
	self.__index = self
  	setmetatable(obj, self)
  	obj.id = id
  	obj.state = animationState.stand
	obj.x = 0
	obj.y = 0
	obj.speed = 2
	obj.image = image
	obj.anim = anim
	obj.direction = direction.down
	obj.frame = 0
	obj.frameDelay = 0
	obj.pos = 1
	obj.nextPos = 1
	obj.dx = 0
	obj.dy = 0
	obj.stop = 0
	return obj
end

function animation:update()
	if self.state == animationState.stand then
		self.frame = 1
	elseif self.state == animationState.move then
		self:updateFrame()
		return self:updatePosition()
	elseif self.state == animationState.play then
		self:updateFrame()
	end
	return true
end

function animation:updateFrame()
	if self.anim then
		self.frameDelay = self.frameDelay + 1
		if self.frameDelay == 6 then
			self.frame = self.frame + 1
			if self.frame >= 3 then
				self.frame = 0
			end
			self.frameDelay = 0
		end
	end
end

function animation:updatePosition()
	if self.state == animationState.move then
		isEnd = false
		if self.direction == direction.left then
			self.x = self.x - self.speed
			if self.x < self.dx then
				self.x = self.dx
				isEnd = true
			end
		elseif self.direction == direction.right then
			self.x = self.x + self.speed
			if self.x > self.dx then
				self.x = self.dx
				isEnd = true
			end
		elseif self.direction == direction.up then
			self.y = self.y - self.speed
			if self.y < self.dy then
				self.y = self.dy
				isEnd = true
			end
		else
			self.y = self.y + self.speed
			if self.y > self.dy then
				self.y = self.dy
				isEnd = true
			end
		end

		if isEnd then
			if self.pos < self.nextPos then
				self.pos = self.pos + 1
			else 
				self.pos = self.pos - 1
			end
			return true
		end
		return false
	end
end

function drawAnimation(image, x, y, direction, frame, scale)
	scale = scale or 1.0
	frame = frame % 3
	width = image:getWidth() * scale
	height = image:getHeight() * scale
	size = width / 3
	rect = love.graphics.newQuad(frame * size, direction * size, size, size, width, height)
	love.graphics.draw(image, rect, x - size / 2, y)
end

function animation:draw(scale)
	scale = scale or 1.0
	width = self.image:getWidth() * scale
	height = self.image:getHeight() * scale

	if self.direction == direction.left then
		rect = love.graphics.newQuad(0, 0, -width, height, -width, height)
		love.graphics.draw(self.image, rect, self.x + width - width / 2, self.y)
	else
		rect = love.graphics.newQuad(0, 0, width, height, width, height)
		love.graphics.draw(self.image, rect, self.x - width / 2, self.y)
	end
end

function animation:setPosition(x, y, dir)
	self.x = x
	self.y = y
	self.dx = x
	self.dy = y
	self.direction = dir or direction.down
end

function animation:setTile(tiles, pos)
	pos = check_pos(tiles, pos)
	self.x, self.y = tiles[pos]:position(self.id)
	self.dx = self.x
	self.dy = self.y
	self.pos = pos
	self.nextPos = pos
end

function getDirection(x1, y1, x2, y2)
	if x1 == x2 then
		if y1 <= y2 then
			return direction.down
		else
			return direction.up
		end
	elseif x1 < x2 then
		return direction.right
	else
		return direction.left
	end
end

function animation:moveNext(tiles)
	if self.pos == self.nextPos then
		self.state = animationState.stand
		self.direction = direction.down
		return 0
	end

	if self.x == self.dx and self.dy == self.dy then
		pos = self.pos
		if self.pos < self.nextPos then
			pos = pos + 1
		else
			pos = pos - 1
		end

		pos = check_pos(tiles, pos);

		self.dx, self.dy = tiles[pos]:position(self.id)
		self.direction = getDirection(self.x, self.y, self.dx, self.dy)
		self.state = animationState.move
	end

	if self:update() then
		return 1
	else
		return -1
	end
end