gameState = {
	null = 0,

	menu = 1,
	loading = 2,
	win = 3,

	start = 10,
	dice = 11,
	moving = 12,
}


function initGame()
	game.state = gameState.menu
	game.round = 0
	game.winner = 0

	player1:setTile(tiles, 1)
	player1.stop = 0

	player2:setTile(tiles, 1)
	player2.stop = 0

	dice.time = 0
	dice.value = 0

	math.randomseed(os.time())
end

function love.load()

	game = {
		state = gameState.menu,
		round = 0,

		winner = 0,
	}

	player1 = animation:new(1, images.player1, false)
	player2 = animation:new(2, images.player2, false)

	dice = {
		time = 0,
		value = 0,
	}

	love.graphics.setBackgroundColor(colors.deepSkyBlue)
	aniFrame = 0
	aniDelay = 0

	initGame()

end


function check_event(player)
	if player.pos > 20 then
		game.winner = player.id
		game.state = gameState.win
	end

	pos = check_pos(tiles, player.pos)

	if tiles[pos].event == event.null then
		return true
	elseif tiles[pos].event == event.start then
		game.winner = player.id
		game.state = gameState.win
		return false
	elseif tiles[pos].event == event.stop then
		player.stop = tiles[pos].value
		return true
	elseif tiles[pos].event == event.move then
		player.nextPos = player.pos + tiles[pos].value
		return false
	else
		return true
	end
end

function playerOnMove(player)
	n = player:moveNext(tiles)
	if n == 0 then
		if check_event(player) then
			game.round = game.round + 1
			game.state = gameState.start
		end
	elseif n == 1 then
		if player.pos > 20 then
			game.winner = player.id
			game.state = gameState.win
			return false
		end
	end
end

function love.update(dt)
	if game.state == gameState.menu then
		player1:updateFrame()
		player2:updateFrame()

	elseif game.state == gameState.start then
		if game.round % 2 == 1 then
			game.state = gameState.dice
			dice.time = 0
		end
	elseif game.state == gameState.dice then
		if game.round % 2 == 0 then
			if player1.stop > 0 then
				player1.stop = player1.stop - 1
				game.round = game.round + 1
				game.state = gameState.start
			end
		else
			if player2.stop > 0 then
				player2.stop = player2.stop - 1
				game.round = game.round + 1
				game.state = gameState.start
			end
		end

		math.randomseed(os.time())
		dice.time = dice.time + dt
		n = love.math.random() * 4 + 1
    	dice.value = math.floor(n)
		if dice.time > 1.0 then
			game.state = gameState.moving
			if game.round % 2 == 0 then
				player1.nextPos = player1.pos + dice.value;
			else
				player2.nextPos = player2.pos + dice.value;
			end
		end

	elseif game.state == gameState.moving then
		if game.round % 2 == 0 then
			playerOnMove(player1)
		else
			playerOnMove(player2)
		end
	end
end