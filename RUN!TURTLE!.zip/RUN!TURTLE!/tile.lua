event = {
	null = 0,
	start = 1,
	move = 2,
	stop = 3,
}

tile = {
	id = 0,
	x = 0,
	y = 0,

	prev_x = 0,
	prev_y = 0,
	next_x = 0,
	next_y = 0,
	
	event = 0,
	text = nil,
	value = 0,
}

function tile:new(id, x, y, ev, text, value)
	obj = {}
	self.__index = self
  	setmetatable(obj, self)
  	obj.id = id
  	obj.x = x
  	obj.y = y
  	obj.event = ev
  	obj.text = text
  	obj.value = value  	
  	return obj
end

function tile:position(player)
	boxWidth = (love.graphics.getWidth() - 4) / 7 - 4
	boxHeight = (love.graphics.getHeight() - 4) / 5 - 4
	x = self.x * (boxWidth + 4) + 4
	y = self.y * (boxHeight + 4) + 4

	if player == 1 then
		return x + boxWidth / 2 - 30, y + boxHeight / 2
	else
		return  x + boxWidth / 2 + 30, y + boxHeight / 2
	end
end

function check_pos(tiles, pos)
	len = table.getn(tiles)
	return ((pos - 1) % len) + 1
end

tiles = {
    tile:new(1, 3, 4, event.start, 'START \n-----\nEND', 0),
    tile:new(2, 2, 4, event.null, 'CAT', 0),
    tile:new(3, 1, 4, event.move, 'HAVD SOME FOOD \n+2', 2),
    tile:new(4, 0, 4, event.move, 'PLAY WITH MONKEY \n-2', -2),

    tile:new(5, 0, 3, event.null, 'BIRD', 0),
    tile:new(6, 0, 2, event.stop, 'PLAY WITH MONKEY \nSTOP', 1),
    tile:new(7, 0, 1, event.null, 'LION', 0),

    tile:new(8, 0, 0, event.move, 'HEAVY WIND \n-3', -3),
    tile:new(9, 1, 0, event.null, 'PIG', 0),
    tile:new(10, 2, 0, event.null, 'TIGER', 0),
    tile:new(11, 3, 0, event.move, 'HAVE SOME WATER \n+2', 2),
    tile:new(12, 4, 0, event.null, 'HORSE', 0),
    tile:new(13, 5, 0, event.null, 'GIRAFFE', 0),
    tile:new(14, 6, 0, event.stop, 'RAINY \nSTOP', 2),

    tile:new(15, 6, 1, event.null, 'SQUIRREL', 0),
    tile:new(16, 6, 2, event.move, 'BEAR \n-1', -1),
    tile:new(17, 6, 3, event.move, 'GET GIFT \n+2', 2),

    tile:new(18, 6, 4, event.null, 'DOG', 0),
    tile:new(19, 5, 4, event.null, 'SUNNY', 0),
    tile:new(20, 4, 4, event.move, 'ALMOST THERE \n-1', -1),
}

function draw_tile(x, y, width, height, text)
	love.graphics.setColor(1.0, 1.0, 1.0, 0.5)
	love.graphics.rectangle('fill', x, y, width, height)
	love.graphics.setColor(colors.black)
	love.graphics.printf(text, x, y + 20, width, "center")
end

function draw_tiles()
	boxWidth = (love.graphics.getWidth() - 4) / 7 - 4
	boxHeight = (love.graphics.getHeight() - 4) / 5 - 4

	love.graphics.setFont(fonts.font16)	
	for i=1,20,1 do
		x = tiles[i].x * (boxWidth + 4) + 4
		y = tiles[i].y * (boxHeight + 4) + 4
		draw_tile(x, y, boxWidth, boxHeight, tiles[i].text)
	end
end